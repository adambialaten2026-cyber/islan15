HTMLHomeScreen widgets
======================
Each widget is a folder with an index.html. Copy the "example" folder, rename it,
edit index.html, then open Settings > HTMLHomeScreen > Custom widget N and type the folder name
into Source. Use background:transparent. Sources can also be https:// links.

Pinning: set "Home Screen page" on a widget to stick it to that icon page so it swipes with the page.
Leave a gap in your icon layout where the widget sits (icons do not reflow around it).
